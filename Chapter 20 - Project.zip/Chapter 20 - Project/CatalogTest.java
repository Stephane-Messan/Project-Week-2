import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.util.List;

public class CatalogTest {
    private Catalog catalog;

    @BeforeEach
    public void setUp() {
        catalog = new Catalog();
        catalog.addBook(new Book("Effective Java", "Joshua Bloch", "0321356683", 45.00));
        catalog.addBook(new Book("Clean Code", "Robert C. Martin", "9780132350884", 41.75));
    }

    @Test
    public void testAddBook() {
        Book book = new Book("Test-Driven Development", "Kent Beck", "0321146530", 37.95);
        catalog.addBook(book);
        Assertions.assertNotNull(catalog.searchByTitle("Test-Driven Development"));
    }

    @Test
    public void testSearchByTitle() {
        List<Book> books = catalog.searchByTitle("Effective Java");
        Assertions.assertFalse(books.isEmpty());
        Assertions.assertEquals("Joshua Bloch", books.get(0).getAuthor());
    }

    @Test
    public void testDisplayBookDetails() {
        // Assuming displayBookDetails prints the details to the console
        // You would need to capture console output to test this properly
    }
}
