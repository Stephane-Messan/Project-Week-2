import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class BookTest {

    @Test
    public void testBookConstructorAndGetters() {
        Book book = new Book("Effective Java", "Joshua Bloch", "0321356683", 45.00);
        Assertions.assertEquals("Effective Java", book.getTitle());
        Assertions.assertEquals("Joshua Bloch", book.getAuthor());
        Assertions.assertEquals("0321356683", book.getIsbn());
        Assertions.assertEquals(45.00, book.getPrice());
    }
}
