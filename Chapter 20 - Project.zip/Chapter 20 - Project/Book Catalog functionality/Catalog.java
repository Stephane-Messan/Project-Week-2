import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Catalog {
    private List<Book> books;

    public Catalog() {
        books = new ArrayList<>();
    }

    // Add a book to the catalog
    public void addBook(Book book) {
        books.add(book);
    }

    // Search for books by title
    public List<Book> searchByTitle(String title) {
        return books.stream()
                    .filter(book -> book.getTitle().equalsIgnoreCase(title))
                    .collect(Collectors.toList());
    }

    // Display book details by ISBN
    public void displayBookDetails(String isbn) {
        books.stream()
             .filter(book -> book.getIsbn().equals(isbn))
             .findFirst()
             .ifPresent(Book::displayBookDetails);
    }

    // Browse all books in the catalog
    public void browseCatalog() {
        books.forEach(Book::displayBookDetails);
    }
}
