import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class BookStore {
    public static void main(String[] args) {
        Catalog catalog = new Catalog();

        // Adding books to the catalog
        catalog.addBook(new Book("The Alchemist", "Paulo Coelho", "9780061122415", 10.20));
        catalog.addBook(new Book("The Little Prince", "Antoine de Saint-Exupery", "9780156012195", 8.99));

        // Searching for a book by title
        System.out.println("Search Results for 'The Alchemist':");
        List<Book> searchResults = catalog.searchByTitle("The Alchemist");
        searchResults.forEach(Book::displayBookDetails);

        // Displaying details of a book by ISBN
        System.out.println("\nDisplaying details for ISBN 9780061122415:");
        catalog.displayBookDetails("9780061122415");

        // Browsing all books in the catalog
        System.out.println("\nBrowsing the entire catalog:");
        catalog.browseCatalog();
    }
}
