import java.util.HashMap;
import java.util.Map;

public class ShoppingCart {
    private Map<String, Item> items;

    public ShoppingCart() {
        items = new HashMap<>();
    }

    // Add an item to the cart
    public void addItem(Item item) {
        if(items.containsKey(item.getName())) {
            Item existingItem = items.get(item.getName());
            existingItem.setQuantity(existingItem.getQuantity() + item.getQuantity());
        } else {
            items.put(item.getName(), item);
        }
    }

    // Remove an item from the cart
    public void removeItem(String itemName) {
        items.remove(itemName);
    }

    // View cart contents
    public void viewCart() {
        if(items.isEmpty()) {
            System.out.println("Your cart is empty.");
        } else {
            System.out.println("Items in your cart:");
            for(Item item : items.values()) {
                System.out.println(item.getName() + " - Quantity: " + item.getQuantity() + " - Price: $" + item.getPrice());
            }
        }
    }
}
