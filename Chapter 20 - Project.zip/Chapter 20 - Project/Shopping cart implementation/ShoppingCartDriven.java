public class ShoppingCartDriven{
    public static void main(String[] args) {
        ShoppingCart cart = new ShoppingCart();

        // Adding items to the cart
        cart.addItem(new Item("Book", 9.99, 2));
        cart.addItem(new Item("Pen", 1.49, 3));
        cart.addItem(new Item("Notebook", 5.49, 1));

        // Viewing cart items
        cart.viewCart();

        // Removing an item from the cart
        cart.removeItem("Pen");

        // Viewing cart items after removal
        cart.viewCart();
    }
}
