public class Main {
    public static void main(String[] args) {
        UserManager userManager = new UserManager();

        // Register a new user
        userManager.registerUser("john_doe", "securepassword123", "john.doe@example.com");

        // Authenticate the user
        boolean isAuthenticated = userManager.authenticateUser("john_doe", "securepassword123");
        System.out.println("Authentication status: " + isAuthenticated);
    }
}
