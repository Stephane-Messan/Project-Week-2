import java.util.HashMap;
import java.util.Map;

public class UserManager {
    private Map<String, User> userMap = new HashMap<>();

    public void registerUser(String username, String password, String email) {
        if (!userMap.containsKey(username)) {
            User newUser = new User(username, password, email);
            userMap.put(username, newUser);
            System.out.println("User registered successfully!");
        } else {
            System.out.println("Username already exists. Please choose a different one.");
        }
    }

    public boolean authenticateUser(String username, String password) {
        if (userMap.containsKey(username)) {
            User user = userMap.get(username);
            if (user.getPassword().equals(password)) {
                System.out.println("User authenticated successfully!");
                return true;
            } else {
                System.out.println("Incorrect password.");
            }
        } else {
            System.out.println("Username does not exist.");
        }
        return false;
    }
}
